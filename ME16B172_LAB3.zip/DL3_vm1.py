>>> f = open('addresses.csv', 'r')
>>> count = 0
>>> for line in f:
...     count += 1
...
>>> count